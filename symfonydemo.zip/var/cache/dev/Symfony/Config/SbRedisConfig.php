<?php

namespace Symfony\Config;

require_once __DIR__.\DIRECTORY_SEPARATOR.'SbRedis'.\DIRECTORY_SEPARATOR.'ClientsConfig.php';

use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class SbRedisConfig implements \Symfony\Component\Config\Builder\ConfigBuilderInterface
{
    private $clients;
    private $_usedProperties = [];

    public function clients(string $default, array $value = []): \Symfony\Config\SbRedis\ClientsConfig
    {
        if (!isset($this->clients[$default])) {
            $this->_usedProperties['clients'] = true;
            $this->clients[$default] = new \Symfony\Config\SbRedis\ClientsConfig($value);
        } elseif (1 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "clients()" has already been initialized. You cannot pass values the second time you call clients().');
        }

        return $this->clients[$default];
    }

    public function getExtensionAlias(): string
    {
        return 'sb_redis';
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('clients', $value)) {
            $this->_usedProperties['clients'] = true;
            $this->clients = array_map(function ($v) { return new \Symfony\Config\SbRedis\ClientsConfig($v); }, $value['clients']);
            unset($value['clients']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['clients'])) {
            $output['clients'] = array_map(function ($v) { return $v->toArray(); }, $this->clients);
        }

        return $output;
    }

}
